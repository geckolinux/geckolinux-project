#!/bin/bash
#================
# FILE          : config.sh
#----------------
# PROJECT       : openSUSE KIWI Image System
# COPYRIGHT     : (c) 2006,2007,2008,2017 SUSE Linux GmbH. All rights reserved
#               :
# AUTHOR        : Marcus Schaefer <ms@suse.de>, Stephan Kulow <coolo@suse.de>, Fabian Vogt <fvogt@suse.com>
#               :
# LICENSE       : BSD
#======================================
# Functions...
#--------------------------------------
test -f /.kconfig && . /.kconfig
test -f /.profile && . /.profile

set -euox pipefail

#--------------------------------------
# enable and disable services

for i in NetworkManager tlp avahi-dnsconfd earlyoom zramswap; do
	systemctl -f enable $i
done
for i in purge-kernels wicked auditd apparmor; do
	systemctl -f disable $i
done

cd /

rm -rf /var/cache/zypp/raw/*

#======================================
# /etc/sudoers hack to fix #297695 
# (Installation Live CD: no need to ask for password of root)
#--------------------------------------
sed -i -e "s/ALL ALL=(ALL) ALL/ALL ALL=(ALL) NOPASSWD: ALL/" /etc/sudoers 
chmod 0440 /etc/sudoers

/usr/sbin/useradd -m -u 999 linux -c "Live-CD User" -p ""  -g users -G audio

# delete passwords
passwd -d root
passwd -d linux
# empty password is ok
pam-config -a --nullok

: > /var/log/zypper.log

chown -R linux:users /home/linux

chkstat --system --set

rm -rf /var/cache/zypp/packages

# bug 544314, we only want to disable the bit in common-auth-pc
sed -i -e 's,^\(.*pam_gnome_keyring.so.*\),#\1,'  /etc/pam.d/common-auth-pc

ln -s /usr/lib/systemd/system/runlevel5.target /etc/systemd/system/default.target
baseUpdateSysConfig /etc/sysconfig/displaymanager DISPLAYMANAGER_AUTOLOGIN linux
baseUpdateSysConfig /etc/sysconfig/keyboard KEYTABLE us.map.gz
baseUpdateSysConfig /etc/sysconfig/keyboard YAST_KEYBOARD "english-us,pc104"
baseUpdateSysConfig /etc/sysconfig/keyboard COMPOSETABLE "clear latin1.add"

baseUpdateSysConfig /etc/sysconfig/language RC_LANG "en_US.UTF-8"

baseUpdateSysConfig /etc/sysconfig/console CONSOLE_FONT "eurlatgr.psfu"
baseUpdateSysConfig /etc/sysconfig/console CONSOLE_SCREENMAP trivial
baseUpdateSysConfig /etc/sysconfig/console CONSOLE_MAGIC "(K"
baseUpdateSysConfig /etc/sysconfig/console CONSOLE_ENCODING "UTF-8"

baseUpdateSysConfig /etc/sysconfig/displaymanager DISPLAYMANAGER lightdm

###baseUpdateSysConfig /etc/sysconfig/windowmanager DEFAULT_WM gnome

#Disable journal write to disk in live mode, bug 950999
echo "Storage=volatile" >> /etc/systemd/journald.conf

#======================================
# GeckoLinux
#--------------------------------------
rm /usr/share/fonts/truetype/Ubuntu-M.ttf
rm /usr/share/fonts/truetype/Ubuntu-MI.ttf
rm -R /usr/etc/skel

# Fix blank /etc/resolv.conf issue, many thanks to "woodyx86" https://github.com/geckolinux/geckolinux-project/issues/123#issuecomment-660502445 
rm /etc/resolv.conf
ln -s /var/run/netconfig/resolv.conf /etc/resolv.conf

# Import RPM repo keys
rpm --import /etc/zypp/repos.d/key-Google.pub
rpm --import /etc/zypp/repos.d/key-Packman.pub
rpm --import /etc/zypp/repos.d/key-Skype.pub
rpm --import /etc/zypp/repos.d/key-openSUSE.pub
rpm --import /etc/zypp/repos.d/key-Nvidia.pub
rm /etc/zypp/repos.d/key-Google.pub
rm /etc/zypp/repos.d/key-Packman.pub
rm /etc/zypp/repos.d/key-Skype.pub
rm /etc/zypp/repos.d/key-openSUSE.pub
rm /etc/zypp/repos.d/key-Nvidia.pub

## Fix gvfs-trash functionality for live session user
mkdir /.Trash-999
chown 999:users /.Trash-999
chmod 700 /.Trash-999

## Don't automatically switch Bluetooth devices to HSP/HFP, use A2DP by default
#sed -i 's/load-module module-bluetooth-policy/load-module module-bluetooth-policy auto_switch=false/g' /etc/pulse/default.pa

## Automatically switch default audio output to newly connected Bluetooth devices
#printf "\n####GeckoLinux####\nload-module module-switch-on-connect" >> /etc/pulse/default.pa

## Enable NTP out-of-the-box
systemctl enable yast-timesync.timer

## PipeWire tweaks for low latency
mkdir /etc/pipewire
cp /usr/share/pipewire/jack.conf /etc/pipewire/
sed -i 's@#nice.level   = -11@nice.level   = -11  ##GeckoLinux default@g' /etc/pipewire/jack.conf
sed -i 's@#rt.prio      = 88@rt.prio      = 90  ##GeckoLinux default@g' /etc/pipewire/jack.conf
sed -i 's@#rt.time.soft = 2000000@rt.time.soft = 3000000  ##GeckoLinux default@g' /etc/pipewire/jack.conf
sed -i 's@#rt.time.hard = 2000000@rt.time.hard = 3000000  ##GeckoLinux default@g' /etc/pipewire/jack.conf
sed -i 's@#node.latency       = 1024/48000@node.latency       = 256/48000  ##GeckoLinux default@g' /etc/pipewire/jack.conf
cp /usr/share/pipewire/pipewire.conf /etc/pipewire/
sed -i 's@# Uses RTKit to boost the data thread priority.@##GeckoLinux default: use internal module instead of RTKit@g' /etc/pipewire/pipewire.conf
sed -i 's@libpipewire-module-rtkit@libpipewire-module-rt@g' /etc/pipewire/pipewire.conf
sed -i 's@#nice.level   = -11@nice.level   = -11  ##GeckoLinux default@g' /etc/pipewire/pipewire.conf
sed -i 's@#rt.prio      = 88@rt.prio      = 90  ##GeckoLinux default@g' /etc/pipewire/pipewire.conf
sed -i 's@#rt.time.soft = 2000000@rt.time.soft = 3000000  ##GeckoLinux default@g' /etc/pipewire/pipewire.conf
sed -i 's@#rt.time.hard = 2000000@rt.time.hard = 3000000  ##GeckoLinux default@g' /etc/pipewire/pipewire.conf
cp /usr/share/pipewire/client-rt.conf /etc/pipewire/
sed -i 's@# Uses RTKit to boost the data thread priority.@##GeckoLinux default: use internal module instead of RTKit@g' /etc/pipewire/client-rt.conf
sed -i 's@libpipewire-module-rtkit@libpipewire-module-rt@g' /etc/pipewire/client-rt.conf
sed -i 's@#nice.level   = -11@nice.level   = -11  ##GeckoLinux default@g' /etc/pipewire/client-rt.conf
sed -i 's@#rt.prio      = 88@rt.prio      = 90  ##GeckoLinux default@g' /etc/pipewire/client-rt.conf
sed -i 's@#rt.time.soft = 2000000@rt.time.soft = 3000000  ##GeckoLinux default@g' /etc/pipewire/client-rt.conf
sed -i 's@#rt.time.hard = 2000000@rt.time.hard = 3000000  ##GeckoLinux default@g' /etc/pipewire/client-rt.conf
sed -i 's@#node.latency = 1024/48000@node.latency = 256/48000  ##GeckoLinux default@g' /etc/pipewire/client-rt.conf
sed -i 's@#node.latency          = 1024/48000@node.latency          = 256/48000  ##GeckoLinux default@g' /etc/pipewire/client-rt.conf
cp /usr/share/pipewire/pipewire-pulse.conf /etc/pipewire/
sed -i 's@#{ path = "pactl"        args = "load-module module-switch-on-connect" }@{ path = "pactl"        args = "load-module module-switch-on-connect" }  ##GeckoLinux default@g' /etc/pipewire/pipewire-pulse.conf
systemctl --global enable pipewire.socket
systemctl --global enable wireplumber.service
printf "\n####GeckoLinux####\nfs.inotify.max_user_watches = 524288" >> /etc/sysctl.conf

## GRUB 2.06 menu generation doesn't run `os-prober` without this:
printf "\nGRUB_DISABLE_OS_PROBER=false\n" >> /etc/default/grub
